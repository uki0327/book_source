package com.example.user.part3_9;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Lab9_2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab9_2);
    }
}
